import socket
import sys
import time
import re

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("127.0.0.1", 1234))
s.listen(1)
(connection, address) = s.accept()
print(f"An client has connected on \
{time.ctime()} with IP: {address[0]} PORT: {address[1]}")
result = 0
while True:
    data = connection.recv(100).decode("UTF-8")
    if "." == data:
        connection.send(str(result).encode())
        break
    else:
        print(data)
        numbers = re.findall(r'(\d+)\|',data)
        print(numbers)
        for number in numbers:
            if "." == number:
                connection.send(str(result).encode())
                break
            else:
                result = result + int(number)

connection.close()
print("Server closed!")
