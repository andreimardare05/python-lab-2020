The file is empty
dat